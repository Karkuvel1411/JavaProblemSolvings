package pongal_work;

public class level2_ques4 {
    public static void main(String[] args) {
        int A =90;
        int B =20;
        int C = 1;

        if (A >= B && A >= C) {
            System.out.println(A);
        } else if (B >= A && B >= C) {
            System.out.println(B);
        } else {
            System.out.println(C);
        }
    }
}
