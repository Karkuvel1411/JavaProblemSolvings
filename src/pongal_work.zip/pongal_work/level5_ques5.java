package pongal_work;

public class level5_ques5 {
    public static void main(String args[])
    {
        String str1 = "hello world123";
        str1 = str1.replaceAll("[^a-zA-Z]", "");

        System.out.println(str1);
    }
}
