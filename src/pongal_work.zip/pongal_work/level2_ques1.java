package pongal_work;

public class level2_ques1 {
    public static void main(String[] args) {
        int find =3;
        int a =2;
        int b=6;
        for(int i =a;i<=b;i++){
            if(i==find){
                System.out.println("Yes");
                break;
//                oaiudyhqadehwugyftsgjcvh
            }
        }
    }
}
